
const express = require("express");
const router = express.Router();

const Project = require("../models/Project");
const Workspace = require("../models/Workspace");
const authMiddleware = require("../middleware/authMiddleware");

// CREATE PROJECT
router.post("/", authMiddleware, async (req, res) => {
    try {
        const {
            name,
            description,
            workspaceId,
            deadline
        } = req.body;

        if (!name || !workspaceId) {
            return res.status(400).json({
                message: "Project name and workspace are required"
            });
        }

        const workspace = await Workspace.findOne({
            _id: workspaceId,
            members: req.user.id
        });

        if (!workspace) {
            return res.status(404).json({
                message: "Workspace not found or access denied"
            });
        }

        const project = await Project.create({
            name,
            description,
            workspace: workspaceId,
            createdBy: req.user.id,
            members: [req.user.id],
            deadline
        });

        res.status(201).json({
            message: "Project created successfully",
            project
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// GET PROJECTS
router.get("/", authMiddleware, async (req, res) => {
    try {
        const workspaces = await Workspace.find({
            members: req.user.id
        }).select("_id");

        const workspaceIds = workspaces.map(w => w._id);

        const projects = await Project.find({
            workspace: { $in: workspaceIds }
        })
        .populate("createdBy", "name email")
        .populate("members", "name email")
        .populate("workspace", "name");

        res.json(projects);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

module.exports = router;
