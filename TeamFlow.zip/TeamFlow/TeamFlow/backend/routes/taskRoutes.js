
const express = require("express");
const router = express.Router();

const Task = require("../models/Task");
const Project = require("../models/Project");
const Notification = require("../models/Notification");
const authMiddleware = require("../middleware/authMiddleware");

// CREATE TASK
router.post("/", authMiddleware, async (req, res) => {
    try {
        const {
            title,
            description,
            projectId,
            assignedTo,
            priority,
            dueDate
        } = req.body || {};

        if (!title || !projectId) {
            return res.status(400).json({
                message: "Task title and projectId are required"
            });
        }

        // Check project access
        const project = await Project.findOne({
            _id: projectId,
            members: req.user.id
        });

        if (!project) {
            return res.status(404).json({
                message: "Project not found or access denied"
            });
        }

        // Check assigned user is a project member
        if (assignedTo && !project.members.some(
            member => member.toString() === assignedTo
        )) {
            return res.status(400).json({
                message: "Assigned user is not a project member"
            });
        }

        // Create task
        const task = await Task.create({
            title,
            description,
            project: projectId,
            assignedTo: assignedTo || undefined,
            createdBy: req.user.id,
            priority: priority || "Medium",
            dueDate: dueDate || undefined
        });

        // Create notification for assigned member
        if (assignedTo && assignedTo !== req.user.id) {
            await Notification.create({
                recipient: assignedTo,
                sender: req.user.id,
                message: `You have been assigned a new task: ${title}`,
                type: "task_assigned",
                relatedTask: task._id
            });
        }

        res.status(201).json({
            message: "Task created successfully",
            task
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// GET TASKS FOR A PROJECT
router.get("/project/:projectId", authMiddleware, async (req, res) => {
    try {
        const project = await Project.findOne({
            _id: req.params.projectId,
            members: req.user.id
        });

        if (!project) {
            return res.status(404).json({
                message: "Project not found or access denied"
            });
        }

        const tasks = await Task.find({
            project: project._id
        })
        .populate("assignedTo", "name email")
        .populate("createdBy", "name email");

        res.json(tasks);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// UPDATE TASK STATUS
router.patch("/:id/status", authMiddleware, async (req, res) => {
    try {
        const { status } = req.body || {};

        const allowedStatuses = [
            "To Do",
            "In Progress",
            "Under Review",
            "Completed"
        ];

        if (!allowedStatuses.includes(status)) {
            return res.status(400).json({
                message: "Invalid task status"
            });
        }

        const task = await Task.findOne({
            _id: req.params.id,
            createdBy: req.user.id
        });

        if (!task) {
            return res.status(404).json({
                message: "Task not found or access denied"
            });
        }

        task.status = status;
        await task.save();

        res.json({
            message: "Task status updated successfully",
            task
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

module.exports = router;
