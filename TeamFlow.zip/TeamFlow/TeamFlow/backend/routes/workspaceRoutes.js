
const express = require("express");
const router = express.Router();

const Workspace = require("../models/Workspace");
const User = require("../models/User");
const authMiddleware = require("../middleware/authMiddleware");

// CREATE WORKSPACE
router.post("/", authMiddleware, async (req, res) => {
    try {
        const { name, description } = req.body;

        if (!name || !name.trim()) {
            return res.status(400).json({
                message: "Workspace name is required"
            });
        }

        const workspace = await Workspace.create({
            name: name.trim(),
            description,
            owner: req.user.id,
            members: [req.user.id]
        });

        res.status(201).json({
            message: "Workspace created successfully",
            workspace
        });

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// GET MY WORKSPACES
router.get("/", authMiddleware, async (req, res) => {
    try {
        const workspaces = await Workspace.find({
            members: req.user.id
        }).populate("owner", "name email");

        res.json(workspaces);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// GET WORKSPACE MEMBERS
router.get("/:workspaceId/members", authMiddleware, async (req, res) => {
    try {
        const workspace = await Workspace.findOne({
            _id: req.params.workspaceId,
            members: req.user.id
        }).populate("members", "name email role");

        if (!workspace) {
            return res.status(404).json({
                message: "Workspace not found or access denied"
            });
        }

        res.json(workspace.members);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// ADD MEMBER TO WORKSPACE
router.post("/:workspaceId/members", authMiddleware, async (req, res) => {
    try {
        const { email } = req.body;

        const workspace = await Workspace.findById(req.params.workspaceId);

        if (!workspace) {
            return res.status(404).json({
                message: "Workspace not found"
            });
        }

        // Only workspace owner can add members
        if (workspace.owner.toString() !== req.user.id) {
            return res.status(403).json({
                message: "Only workspace owner can add members"
            });
        }

        if (!email || !email.trim()) {
            return res.status(400).json({
                message: "Email is required"
            });
        }

        const member = await User.findOne({
            email: email.trim().toLowerCase()
        });

        if (!member) {
            return res.status(404).json({
                message: "User not registered. Ask them to register first."
            });
        }

        if (workspace.members.some(id => id.toString() === member._id.toString())) {
            return res.status(400).json({
                message: "User is already a workspace member"
            });
        }

        workspace.members.push(member._id);
        await workspace.save();

        res.status(200).json({
            message: "Team member added successfully",
            member: {
                id: member._id,
                name: member.name,
                email: member.email,
                role: member.role
            }
        });

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
