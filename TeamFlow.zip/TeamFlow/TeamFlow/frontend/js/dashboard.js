
const API_URL = "http://localhost:5000/api";

const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user") || "null");

// Check login
if (!token || !user) {
    window.location.href = "login.html";
} else {
    document.getElementById("welcome").textContent =
        "Welcome back, " + user.name + "!";
}

// API request function
async function fetchData(url) {
    const response = await fetch(url, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });

    if (!response.ok) {
        throw new Error("Unable to load dashboard data");
    }

    return await response.json();
}

// Load dashboard statistics
async function loadDashboard() {
    try {
        // Get all projects
        const projects = await fetchData(`${API_URL}/projects`);

        let allTasks = [];

        // Get tasks from every project
        for (const project of projects) {
            const tasks = await fetchData(
                `${API_URL}/tasks/project/${project._id}`
            );

            allTasks = allTasks.concat(tasks);
        }

        // Calculate statistics
        const totalProjects = projects.length;
        const totalTasks = allTasks.length;

        const completedTasks = allTasks.filter(
            task => task.status === "Completed"
        ).length;

        const pendingTasks = totalTasks - completedTasks;

        // Display statistics
        document.getElementById("totalProjects").textContent =
            totalProjects;

        document.getElementById("totalTasks").textContent =
            totalTasks;

        document.getElementById("completedTasks").textContent =
            completedTasks;

        document.getElementById("pendingTasks").textContent =
            pendingTasks;

        // Display recent tasks
        displayRecentTasks(allTasks);

    } catch (error) {
        console.error("Dashboard Error:", error.message);

        document.getElementById("recentTasks").textContent =
            "Unable to load dashboard data. Please refresh.";
    }
}

// Display recent tasks
function displayRecentTasks(tasks) {
    const container = document.getElementById("recentTasks");
    container.replaceChildren();

    if (tasks.length === 0) {
        container.textContent = "No tasks available.";
        return;
    }

    // Sort by latest created date
    const recentTasks = [...tasks]
        .sort((a, b) =>
            new Date(b.createdAt) - new Date(a.createdAt)
        )
        .slice(0, 5);

    recentTasks.forEach(task => {
        const card = document.createElement("div");
        card.className = "task-item";

        const title = document.createElement("h3");
        title.textContent = task.title;

        const status = document.createElement("p");
        status.textContent = "Status: " + task.status;

        const priority = document.createElement("p");
        priority.textContent = "Priority: " + task.priority;

        card.append(title, status, priority);
        container.appendChild(card);
    });
}

// Logout
function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    window.location.href = "login.html";
}

// Start dashboard
if (token && user) {
    loadDashboard();
}
