
const API_URL = "http://localhost:5000/api";

const token = localStorage.getItem("token");

const params = new URLSearchParams(window.location.search);
const projectId = params.get("projectId");

if (!token) {
    window.location.href = "login.html";
}

if (!projectId) {
    alert("Project ID is missing!");
}

const columns = {
    "To Do": "todo",
    "In Progress": "progress",
    "Under Review": "review",
    "Completed": "completed"
};

async function loadTasks() {
    try {
        const response = await fetch(
            `${API_URL}/tasks/project/${projectId}`,
            {
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );
        if (!response.ok) {
    const errorData = await response.json();

    console.log("API Error:", errorData);

    throw new Error(
        errorData.message || "Unable to load tasks"
    );
}
        const tasks = await response.json();

        Object.values(columns).forEach(id => {
            document.getElementById(id).innerHTML = "";
        });

        const counts = {
            "To Do": 0,
            "In Progress": 0,
            "Under Review": 0,
            "Completed": 0
        };

        tasks.forEach(task => {
            const columnId = columns[task.status];

            if (!columnId) return;

            counts[task.status]++;

            const card = document.createElement("div");
            card.className = "task-card";

            const title = document.createElement("h4");
            title.textContent = task.title;

            const description = document.createElement("p");
            description.textContent = task.description || "No description";

            const priority = document.createElement("p");
            priority.textContent = "Priority: " + task.priority;

            const select = document.createElement("select");

            Object.keys(columns).forEach(status => {
                const option = document.createElement("option");
                option.value = status;
                option.textContent = status;
                option.selected = status === task.status;
                select.appendChild(option);
            });

            select.addEventListener("change", () => {
                updateTaskStatus(task._id, select.value);
            });

            card.append(title, description, priority, select);

            document.getElementById(columnId).appendChild(card);
        });

        document.getElementById("count-todo").textContent = counts["To Do"];
        document.getElementById("count-progress").textContent = counts["In Progress"];
        document.getElementById("count-review").textContent = counts["Under Review"];
        document.getElementById("count-completed").textContent = counts["Completed"];

    } catch (error) {
        alert(error.message);
    }
}

async function updateTaskStatus(taskId, status) {
    try {
        const response = await fetch(
            `${API_URL}/tasks/${taskId}/status`,
            {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({ status })
            }
        );

        if (!response.ok) {
            throw new Error("Unable to update task status");
        }

        alert("Task status updated!");
        loadTasks();

    } catch (error) {
        alert(error.message);
    }
}

if (projectId) {
    loadTasks();
}
