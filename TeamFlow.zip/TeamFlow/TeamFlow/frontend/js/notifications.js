
const API_URL = "http://localhost:5000/api";

const token = localStorage.getItem("token");

const container = document.getElementById("notificationsContainer");
const unreadCount = document.getElementById("unreadCount");

let notifications = [];
let currentFilter = "all";

// Check login
if (!token) {
    window.location.href = "login.html";
}

// Fetch notifications
async function loadNotifications() {
    try {
        const response = await fetch(`${API_URL}/notifications`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error("Failed to load notifications");
        }

        notifications = await response.json();

        updateUnreadCount();
        displayNotifications();

    } catch (error) {
        container.textContent = error.message;
    }
}

// Update unread count
function updateUnreadCount() {
    const count = notifications.filter(
        notification => !notification.isRead
    ).length;

    unreadCount.textContent = count;
}

// Display notifications
function displayNotifications() {
    container.innerHTML = "";

    let filteredNotifications = notifications;

    if (currentFilter === "unread") {
        filteredNotifications = notifications.filter(
            notification => !notification.isRead
        );
    }

    if (currentFilter === "read") {
        filteredNotifications = notifications.filter(
            notification => notification.isRead
        );
    }

    if (filteredNotifications.length === 0) {
        container.innerHTML = `
            <div class="empty-message">
                <h3>No notifications found</h3>
                <p>You are all caught up!</p>
            </div>
        `;
        return;
    }

    filteredNotifications.forEach(notification => {
        const card = document.createElement("div");

        card.className = notification.isRead
            ? "notification-card read"
            : "notification-card";

        const info = document.createElement("div");
        info.className = "notification-info";

        const heading = document.createElement("h3");
        heading.textContent = notification.type.replaceAll("_", " ").toUpperCase();

        const message = document.createElement("p");
        message.textContent = notification.message;

        const date = document.createElement("small");
        date.textContent = new Date(notification.createdAt).toLocaleString();

        info.append(heading, message, date);

        const buttons = document.createElement("div");
        buttons.className = "notification-buttons";

        if (!notification.isRead) {
            const readButton = document.createElement("button");
            readButton.className = "read-btn";
            readButton.textContent = "Mark Read";

            readButton.addEventListener("click", () => {
                markAsRead(notification._id);
            });

            buttons.appendChild(readButton);
        }

        const deleteButton = document.createElement("button");
        deleteButton.className = "delete-btn";
        deleteButton.textContent = "Delete";

        deleteButton.addEventListener("click", () => {
            deleteNotification(notification._id);
        });

        buttons.appendChild(deleteButton);

        card.append(info, buttons);
        container.appendChild(card);
    });
}

// Mark as read
async function markAsRead(id) {
    try {
        const response = await fetch(
            `${API_URL}/notifications/${id}/read`,
            {
                method: "PATCH",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        if (!response.ok) {
            throw new Error("Unable to mark notification as read");
        }

        await loadNotifications();

    } catch (error) {
        alert(error.message);
    }
}

// Delete notification
async function deleteNotification(id) {
    if (!confirm("Are you sure you want to delete this notification?")) {
        return;
    }

    try {
        const response = await fetch(
            `${API_URL}/notifications/${id}`,
            {
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        if (!response.ok) {
            throw new Error("Unable to delete notification");
        }

        await loadNotifications();

    } catch (error) {
        alert(error.message);
    }
}

// Filter buttons
document.getElementById("allBtn").addEventListener("click", () => {
    currentFilter = "all";
    setActiveButton("allBtn");
    displayNotifications();
});

document.getElementById("unreadBtn").addEventListener("click", () => {
    currentFilter = "unread";
    setActiveButton("unreadBtn");
    displayNotifications();
});

document.getElementById("readBtn").addEventListener("click", () => {
    currentFilter = "read";
    setActiveButton("readBtn");
    displayNotifications();
});

function setActiveButton(id) {
    document.querySelectorAll(".filter-btn").forEach(button => {
        button.classList.remove("active");
    });

    document.getElementById(id).classList.add("active");
}

// Logout
document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "login.html";
});

// Initial load
loadNotifications();
