
const API_URL = "http://localhost:5000/api";
const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user") || "null");

if (!token || !user) {
    window.location.href = "login.html";
}

// Load workspaces
async function loadWorkspaces() {
    try {
        const response = await fetch(`${API_URL}/workspaces`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error("Unable to load workspaces");
        }

        const workspaces = await response.json();
        const select = document.getElementById("workspace");

        select.innerHTML = '<option value="">Select Workspace</option>';

        workspaces.forEach(workspace => {
            const option = document.createElement("option");
            option.value = workspace._id;
            option.textContent = workspace.name;
            select.appendChild(option);
        });

        if (workspaces.length === 0) {
            select.innerHTML = '<option value="">No workspaces found</option>';
        }

    } catch (error) {
        console.error(error);
        document.getElementById("message").textContent =
            "Unable to load workspaces.";
    }
}

// Create project
document.getElementById("projectForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const name = document.getElementById("projectName").value.trim();
    const description = document.getElementById("projectDescription").value.trim();
    const workspaceId = document.getElementById("workspace").value;
    const message = document.getElementById("message");

    if (!workspaceId) {
        message.textContent = "Please select a workspace.";
        return;
    }

    try {
        const response = await fetch(`${API_URL}/projects`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify({
                name,
                description,
                workspaceId
            })
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || "Project creation failed");
        }

        message.textContent = "Project created successfully!";
        document.getElementById("projectForm").reset();

        await loadProjects();

    } catch (error) {
        message.textContent = error.message;
    }
});

// Load projects
async function loadProjects() {
    const container = document.getElementById("projectsContainer");

    try {
        const response = await fetch(`${API_URL}/projects`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error("Unable to load projects");
        }

        const projects = await response.json();
        container.replaceChildren();

        if (projects.length === 0) {
            container.textContent = "No projects available.";
            return;
        }

        projects.forEach(project => {
            const card = document.createElement("div");
            card.className = "project-card";

            const title = document.createElement("h3");
            title.textContent = project.name;

            const description = document.createElement("p");
            description.textContent = project.description || "No description";

            const status = document.createElement("p");
            status.textContent = "Status: " + project.status;

            const link = document.createElement("a");
            link.textContent = "Open Kanban Board";
            link.href = `kanban.html?projectId=${encodeURIComponent(project._id)}`;

            card.append(title, description, status, link);
            container.appendChild(card);
        });

    } catch (error) {
        console.error(error);
        container.textContent = error.message;
    }
}

// Logout
function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "login.html";
}

// Initial loading
if (token && user) {
    loadWorkspaces();
    loadProjects();
}
