
const API_URL = "http://localhost:5000/api";
const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user") || "null");

if (!token || !user) {
    window.location.href = "login.html";
}

// Load projects
async function loadProjects() {
    const response = await fetch(`${API_URL}/projects`, {
        headers: { Authorization: `Bearer ${token}` }
    });

    if (!response.ok) {
        throw new Error("Unable to load projects");
    }

    const projects = await response.json();
    const select = document.getElementById("project");

    select.innerHTML = '<option value="">Select Project</option>';

    projects.forEach(project => {
        const option = document.createElement("option");
        option.value = project._id;
        option.textContent = project.name;
        select.appendChild(option);
    });
}

// Load tasks from all projects
async function loadTasks() {
    const projectsResponse = await fetch(`${API_URL}/projects`, {
        headers: { Authorization: `Bearer ${token}` }
    });

    if (!projectsResponse.ok) {
        throw new Error("Unable to load projects");
    }

    const projects = await projectsResponse.json();
    const container = document.getElementById("tasksContainer");

    container.replaceChildren();

    let allTasks = [];

    for (const project of projects) {
        const response = await fetch(
            `${API_URL}/tasks/project/${project._id}`,
            { headers: { Authorization: `Bearer ${token}` } }
        );

        if (!response.ok) {
            throw new Error("Unable to load tasks");
        }

        const tasks = await response.json();

        tasks.forEach(task => {
            task.projectName = project.name;
        });

        allTasks = allTasks.concat(tasks);
    }

    if (allTasks.length === 0) {
        container.textContent = "No tasks available.";
        return;
    }

    allTasks.forEach(task => {
        const card = document.createElement("div");
        card.className = "task-card";

        const title = document.createElement("h3");
        title.textContent = task.title;

        const description = document.createElement("p");
        description.textContent = task.description || "No description";

        const project = document.createElement("p");
        project.textContent = "Project: " + task.projectName;

        const priority = document.createElement("p");
        priority.textContent = "Priority: " + task.priority;

        const status = document.createElement("p");
        status.textContent = "Status: " + task.status;

        const assigned = document.createElement("p");
        assigned.textContent =
            "Assigned To: " + (task.assignedTo?.name || "Unassigned");

        card.append(title, description, project, priority, status, assigned);
        container.appendChild(card);
    });
}

// Create task
document.getElementById("taskForm").addEventListener("submit", async event => {
    event.preventDefault();

    const message = document.getElementById("message");

    const taskData = {
        title: document.getElementById("title").value.trim(),
        description: document.getElementById("description").value.trim(),
        projectId: document.getElementById("project").value,
        assignedTo: document.getElementById("assignedTo").value || undefined,
        priority: document.getElementById("priority").value,
        dueDate: document.getElementById("dueDate").value || undefined
    };

    try {
        const response = await fetch(`${API_URL}/tasks`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify(taskData)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || "Task creation failed");
        }

        message.textContent = "Task created successfully!";
        event.target.reset();

        await loadTasks();

    } catch (error) {
        message.textContent = error.message;
    }
});

// Logout
function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "login.html";
}

// Initial loading
async function initializeTasks() {
    try {
        await loadProjects();
        await loadTasks();
    } catch (error) {
        document.getElementById("message").textContent = error.message;
        console.error(error);
    }
}

if (token && user) {
    initializeTasks();
}
