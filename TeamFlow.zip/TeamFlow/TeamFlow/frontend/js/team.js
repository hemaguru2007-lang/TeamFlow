
const API_URL = "http://localhost:5000/api";
const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user") || "null");

if (!token || !user) {
    window.location.href = "login.html";
}

const workspaceSelect = document.getElementById("workspace");
const membersContainer = document.getElementById("membersContainer");
const message = document.getElementById("message");

// Load workspaces
async function loadWorkspaces() {
    const response = await fetch(`${API_URL}/workspaces`, {
        headers: { Authorization: `Bearer ${token}` }
    });

    if (!response.ok) {
        throw new Error("Unable to load workspaces");
    }

    const workspaces = await response.json();

    workspaceSelect.innerHTML =
        '<option value="">Select Workspace</option>';

    workspaces.forEach(workspace => {
        const option = document.createElement("option");
        option.value = workspace._id;
        option.textContent = workspace.name;
        workspaceSelect.appendChild(option);
    });

    if (workspaces.length > 0) {
        workspaceSelect.value = workspaces[0]._id;
        await loadMembers();
    } else {
        membersContainer.textContent = "No workspaces found.";
    }
}

// Load workspace members
async function loadMembers() {
    const workspaceId = workspaceSelect.value;

    if (!workspaceId) return;

    membersContainer.textContent = "Loading members...";

    try {
        const response = await fetch(
            `${API_URL}/workspaces/${workspaceId}/members`,
            {
                headers: { Authorization: `Bearer ${token}` }
            }
        );

        const members = await response.json();

        if (!response.ok) {
            throw new Error(members.message || "Unable to load members");
        }

        membersContainer.replaceChildren();

        if (members.length === 0) {
            membersContainer.textContent = "No members found.";
            return;
        }

        members.forEach(member => {
            const card = document.createElement("div");
            card.className = "member-card";

            const name = document.createElement("h3");
            name.textContent = member.name;

            const email = document.createElement("p");
            email.textContent = "Email: " + member.email;

            const role = document.createElement("p");
            role.textContent = "Role: " + member.role;

            card.append(name, email, role);
            membersContainer.appendChild(card);
        });

    } catch (error) {
        membersContainer.textContent = error.message;
    }
}

// Change workspace
workspaceSelect.addEventListener("change", loadMembers);

// Add member
document.getElementById("memberForm").addEventListener(
    "submit",
    async event => {
        event.preventDefault();

        const workspaceId = workspaceSelect.value;
        const email = document.getElementById("memberEmail").value.trim();

        try {
            const response = await fetch(
                `${API_URL}/workspaces/${workspaceId}/members`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`
                    },
                    body: JSON.stringify({ email })
                }
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || "Unable to add member");
            }

            message.textContent = result.message;
            event.target.reset();
            await loadMembers();

        } catch (error) {
            message.textContent = error.message;
        }
    }
);

// Logout
function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "login.html";
}

// Initialize
loadWorkspaces().catch(error => {
    membersContainer.textContent = error.message;
    console.error(error);
});
